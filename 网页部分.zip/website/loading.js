document.querySelector("body").onload=function(){
    function easeout(a,ele,cbk=function(ele){},j=0.05){
        
        if(a>=0){
        ele.style.opacity=a
        setTimeout(easeout,10,a-j,ele,cbk,j);
        }
        else{
            ele.style.opacity=0;
            cbk(ele)
        }
}
easeout(1,document.querySelector("body > div.loadingpage"),function(ele){ele.remove()},0.03);

}